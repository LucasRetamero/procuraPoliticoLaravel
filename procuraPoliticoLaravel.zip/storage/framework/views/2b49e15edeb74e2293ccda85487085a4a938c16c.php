    
    <!-- Footer -->
    <footer class="bg-black small text-center text-white-50">
       <div class="container">
      <?php echo $__env->make('home.contato.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo e(URL::asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Plugin JavaScript -->
    <script src="<?php echo e(URL::asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for this template -->
    <script src="<?php echo e(URL::asset('js/grayscale.min.js')); ?>"></script>
