<!DOCTYPE html>
<html>
<head>
   <?php echo $__env->make('home.head.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
 <?php echo $__env->make('home.menu.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('home.title.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('eleito.presidente.section.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('home.footer.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>