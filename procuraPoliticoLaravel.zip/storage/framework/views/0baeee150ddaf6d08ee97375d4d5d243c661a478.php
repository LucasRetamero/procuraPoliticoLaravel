<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Informações</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
    <div class="row">
    <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user-circle fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Eleitos Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoEleito); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.eleitos.lista')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>  
     <!-- // -->
    <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user-circle fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Presidentes Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoPresidente); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.eleitos.lista')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>  
      <!-- // -->
     <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user-circle fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Deputado Federais Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoDeputadoFederal); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.eleitos.lista')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>  
     <!-- // -->
     <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user-circle fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Senadores Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoSenador); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.eleitos.lista')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>  
     <!-- // -->
     <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user-circle fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Governadores Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoGovernador); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.eleitos.lista')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>  
     <!-- // -->
     <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user-circle fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Deputado Estaduais Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoDeputadoEstadual); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.eleitos.lista')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>  
     <!-- // -->
     <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user-circle fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Veradores Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoVereador); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.eleitos.lista')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div> 
     <!-- // -->
     <div class="col-lg-3 col-md-6">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fas fa-layer-group fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Partidos Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoPartido); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.partidos.lista')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>   
     <!-- // -->
     <div class="col-lg-3 col-md-6">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fas fa-layer-group fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Cargos Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoGrupo); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.grupos.lista')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
     <!-- // -->
     <div class="col-lg-3 col-md-6">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fas fa-file-contract fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Contatos Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoContato); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.contato.lista')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
     <!-- // -->
     <div class="col-lg-3 col-md-6">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fas fa-user fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div>Usuarios Cadastrados</div>
                                    <div class="huge"><?php echo e($dadoUsuario); ?></div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(url('/admin/users')); ?>">
                            <div class="panel-footer">
                                <span class="pull-left">Ver Lista</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div> 
                 
                 
    </div><!--End ROW-->
    </div><!--End CONTAINE-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>