<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Editar as informação do Eleitor</div>
                    <div class="card-body">
                        <a href="<?php echo e(url('/admin/eleitos')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
  <?php $__currentLoopData = $eleito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form method="post" action="<?php echo e(route('admin.eleitos.atualizar')); ?>">
  <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
  <input type="hidden" name="id" value="<?php echo e($list->id); ?>"/>
  <div class="form-group">
    <label for="exampleInputEmail1"></label>
    <select class="form-control" id="exampleFormControlSelect1" name="partido_id">
      <option value="0">Selecionar Partido</option>
      <?php $__currentLoopData = $dadoPartidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($item->id); ?>" <?php echo e(("$list->partido_id" == $item->id ? "selected":"")); ?>><?php echo e($item->nome); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"></label>
    <select class="form-control" id="exampleFormControlSelect2" name="grupo_id">
      <option value="0">Selecionar Grupo</option>
      <?php $__currentLoopData = $dadoGrupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($item->id); ?>" <?php echo e(("$list->grupo_id" == $item->id ? "selected":"")); ?>><?php echo e($item->nome); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Imagem</label>
    <input type="text" class="form-control" id="exampleInputPicture1" placeholder="Insira a url da imagem" name="imagem" value="<?php echo e($list->imagem); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Nome</label>
    <input type="text" class="form-control" id="exampleInputName1" placeholder="Insira o nome do eleitor" name="nome" value="<?php echo e($list->nome); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Naturalidade</label>
    <input type="text" class="form-control" id="exampleInputCountry1" placeholder="Insira a naturalidade do eleitor" name="naturalidade" value="<?php echo e($list->naturalidade); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Nascimento</label>
    <input type="date" class="form-control" id="exampleInputBorn1" name="nascimento" value="<?php echo e($list->nascimento); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"></label>
    <select class="form-control" id="exampleFormControlSelect3" name="sexo">
      <option value="0">Selecionar Sexo</option>
      <option value="Masculino" <?php echo e(("$list->sexo" == 'Masculino' ? 'selected' : '')); ?>>Masculino</option>
      <option value="Feminino"  <?php echo e(("$list->sexo" == 'Feminino' ? 'selected' : '')); ?>>Feminino</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"></label>
    <select class="form-control" id="exampleFormControlSelect4" name="estado">
      <option value="0">Selecionar Unidade Federativa</option>
      <?php $__currentLoopData = $dadoEstados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($item->nome); ?>" <?php echo e(("$list->estado" == $item->nome ? "selected":"")); ?>><?php echo e($item->nome); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Gabinete</label>
    <input type="text" class="form-control" id="exampleInputAddress1" placeholder="Insira o gabinete do eleitor" name="gabinete" value="<?php echo e($list->gabinete); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Telefone</label>
    <input type="text" class="form-control" id="exampleInputPhone1" placeholder="Insira o telefone do eleitor" name="telefone" value="<?php echo e($list->telefone); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Email</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Insira o email do eleitor" name="email" value="<?php echo e($list->email); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Site</label>
    <input type="text" class="form-control" id="exampleInputWeb1" placeholder="Insira o site do eleitor" name="site" value="<?php echo e($list->site); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Escritorio</label>
    <input type="text" class="form-control" id="exampleInputBusiness1" placeholder="Insira o escritorio do eleitor" name="escritorio" value="<?php echo e($list->escritorio); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Escolaridade</label>
    <input type="text" class="form-control" id="exampleInputSchool1" placeholder="Insira a escolaridade do eleitor" name="escolaridade" value="<?php echo e($list->escolaridade); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"></label>
    <select class="form-control" id="exampleFormControlSelect5" name="status">
      <option value="0">Selecionar Status</option>
      <?php $__currentLoopData = $dadoGrupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($item->nome); ?>" <?php echo e(( "$list->status" == $item->nome ? "selected":"")); ?>><?php echo e($item->nome); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Biografia</label>
    <textarea  class="form-control" id="exampleInputMessage1" placeholder="Insira a biografia do eleitor" name="biografia"><?php echo e($list->biografia); ?></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Projetos</label>
    <textarea  class="form-control" id="exampleInputMessage2" placeholder="Insira os projetos do eleitor" name="projetos"><?php echo e($list->projetos); ?></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Processos</label>
    <textarea  class="form-control" id="exampleInputMessage3" placeholder="Insira os processos do eleitor" name="processos"><?php echo e($list->processos); ?></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Partidos/Mandatos</label>
    <textarea  class="form-control" id="exampleInputMessage4" placeholder="Insira os partidos\Mandato do eleitor" name="partidos"><?php echo e($list->partidos); ?></textarea>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <button type="submit" class="btn btn-success btn-lg btn-block" name="btnAcao">Editar Eleitor</button>
</form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>