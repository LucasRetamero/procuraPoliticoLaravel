<?php $__env->startSection('content'); ?>

<p> olá</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('eleito.presidente.iniciar.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>