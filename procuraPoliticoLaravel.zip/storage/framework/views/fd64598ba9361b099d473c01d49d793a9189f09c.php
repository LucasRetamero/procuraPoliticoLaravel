<section id="contato" class="contact-section bg-black">
 <!-- Inicio Saida do tratamento de erro -->
 <?php if(isset($errors) && count($errors) > 0): ?>
 <div class="alert bg-warning" role="alert">
 <ul>
 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="font-weight-normal text-dark"><?php echo e($erro); ?></li>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
 <?php endif; ?>
 <!-- Fim Saida do tratamento de erro -->
<form method="post" action="<?php echo e(route('home.contato.enviar')); ?>">
  <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
  <div class="form-group">
    <label for="formGroupExampleInput" class="p-3 mb-2 bg-warning text-dark">Nome</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Insira seu nome" value="<?php echo e(old('nome')); ?>" name="nome">
  </div>
  
  <div class="form-group">
    <label for="formGroupExampleInput2" class="p-3 mb-2 bg-warning text-dark">Email</label>
    <input type="email" class="form-control" id="formGroupExampleInput2" placeholder="Insira seu e-mail" value="<?php echo e(old('email')); ?>" name="email">
  </div>
  
  <div class="form-group">
  <label for="formGroupExampleInput2" class="p-3 mb-2 bg-warning text-dark">Assunto</label>
  <select class="custom-select mb-2 mr-sm-2 mb-sm-0" id="inlineFormCustomSelect" value="<?php echo e(old('assunto')); ?>"name="assunto">
    <option>Escolher</option>
    <option <?php echo e(old('assunto') == 'Outros' ? 'selected' : ''); ?>>Outros</option>
    <option <?php echo e(old('assunto') == 'Sugestão' ? 'selected' : ''); ?>>Sugestão</option>
    <option <?php echo e(old('assunto') == 'Reclamação' ? 'selected' : ''); ?>>Reclamação</option>
    <option <?php echo e(old('assunto') == 'FeedBack' ? 'selected' : ''); ?>>FeedBack</option>
  </select>
  </div>

   <div class="form-group">
    <label for="formGroupExampleInput2" class="p-3 mb-2 bg-warning text-dark">Mensagem</label>
    <textarea class="form-control" id="exampleTextarea" rows="3" name="menssagem"><?php echo e(old('menssagem')); ?></textarea>
  </div>
  <button type="submit" class="btn btn-warning btn-lg btn-block">Enviar Contato</button>
</form>
    </section>