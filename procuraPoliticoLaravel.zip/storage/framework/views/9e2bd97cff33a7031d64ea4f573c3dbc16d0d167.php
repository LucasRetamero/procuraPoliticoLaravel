<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Contatos</div>
                    <div class="card-body">
                        <!--<a href="<?php echo e(route('admin.grupos.form.cadastrar')); ?>" class="btn btn-success btn-sm" title="Add New User">
                            <i class="fa fa-plus" aria-hidden="true"></i> Adicionar novo
                        </a>-->
                       
                        <form method="post" action="<?php echo e(route('admin.contato.lista.filtrar')); ?>">
                        <br/>
                        <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
                        <div class="form-group">
                        <select class="form-control" id="exampleFormControlSelect1" name="assunto">
                        <option value="0">Pesquisar pelo Assunto</option>
                        <option value="Outros">Outros</option>
                        <option value="Sugestão">Sugestão</option>
                        <option value="Reclamação">Reclamação</option>
                        <option value="FeedBack">FeedBack</option>
                       </select>
                       </div>
                       <div class="form-group">
                       <button type="submit" class="btn btn-warning btn-lg btn-block">Pesquisar</button>
                       </div>
                        </form>
                         
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th><th>nome</th><th>e-mail</th><th>assunto</th><th>menssagem</th><th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $eleito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->nome); ?></td>  
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->assunto); ?></td>  
                                        <td><?php echo e($item->menssagem); ?></td>               
                                        <td>
                                            <a href="<?php echo e(route('admin.contato.show',['id'=>$item->id])); ?>" title="View User"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i></button></a>
                                            <!--<a href="<?php echo e(route('admin.grupo.form.atualizar',['id'=>$item->id])); ?>" title="Edit User"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>-->
                                            <?php echo Form::open([
                                                'method' => 'get',
                                                'route' => ['admin.contato.deletar', $item->id],
                                                'style' => 'display:inline'
                                            ]); ?>

                                                <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i>', array(
                                                        'type' => 'submit',
                                                        'class' => 'btn btn-danger btn-sm',
                                                        'title' => 'Deletar Contato',
                                                        'onclick'=>'return confirm("Deletar Contato?")'
                                                )); ?>

                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>