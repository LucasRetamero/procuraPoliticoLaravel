<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Eleitos</div>
                    <div class="card-body">
                        <a href="<?php echo e(route('admin.eleitos.form.cadastrar')); ?>" class="btn btn-success btn-sm" title="Add New User">
                            <i class="fa fa-plus" aria-hidden="true"></i> Adicionar novo
                        </a>
                       
                        <form method="post" action="<?php echo e(route('admin.eleitos.lista.filtrada')); ?>">
                        <br/>
                        <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
                        <div class="form-group">
                        <select class="form-control" id="exampleFormControlSelect1" name="grupo_id">
                        <option value="0">Pesquisar pelo Grupo</option>
                        <?php $__currentLoopData = $dadoGrupo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                       </div>
                       <div class="form-group">
                       <button type="submit" class="btn btn-warning btn-lg btn-block">Pesquisar</button>
                       </div>
                        </form>
                         
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th><th>partido_id</th><th>grupo_id</th><th>Nome</th><th>Sexo</th><th>Estado</th><th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $eleito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><a href="<?php echo e(url('/admin/users', $item->id)); ?>"><?php echo e($item->partido_id); ?></a></td>
                                        <td><?php echo e($item->grupo_id); ?></td>
                                        <td><?php echo e($item->nome); ?></td>
                                        <td><?php echo e($item->sexo); ?></td>
                                        <td><?php echo e($item->estado); ?></td>              
                                        <td>
                                            <a href="<?php echo e(route('admin.eleitos.perfil',['id'=>$item->id])); ?>" title="View User"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i></button></a>
                                            <a href="<?php echo e(route('admin.eleitos.form.atualizar',['id'=>$item->id])); ?>" title="Edit User"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>
                                            <?php echo Form::open([
                                                'method' => 'DELETE',
                                                'url' => ['/admin/eleitos/deletar', $item->id],
                                                'style' => 'display:inline'
                                            ]); ?>

                                                <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i>', array(
                                                        'type' => 'submit',
                                                        'class' => 'btn btn-danger btn-sm',
                                                        'title' => 'Deletar Eleitor',
                                                        'onclick'=>'return confirm("Deletar Eleitor?")'
                                                )); ?>

                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>