<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Contatos</div>
                    <div class="card-body">
                    <?php $__currentLoopData = $eleito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('/admin/contatos')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                       <!--<a href="<?php echo e(route('admin.eleitos.form.cadastrar')); ?>" class="btn btn-success btn-sm" title="Add New User">
                            <i class="fa fa-plus" aria-hidden="true"></i> Adicionar novo
                        </a>-->
                        <!--<a href="<?php echo e(route('admin.eleitos.form.atualizar',['id'=>$item->id])); ?>" title="Edit User"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button></a>-->   
                        <a class="btn btn-danger btn-sm" onclick="return confirm('Deletar Contato?')" href="<?php echo e(route('admin.contato.deletar', $item->id)); ?>"><i class="fa fa-trash"></i> Deletar</a>            
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                    <th>ID</th><th>nome</th><th>e-mail</th><th>assunto</th><th>Menssagem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->nome); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->assunto); ?></td>
                                        <td><?php echo e($item->menssagem); ?></td>          
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>