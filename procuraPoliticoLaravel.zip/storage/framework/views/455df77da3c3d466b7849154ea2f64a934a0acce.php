<div class="card">
  <h5 class="card-header">Pesquisar</h5>
  <div class="card-body">
  <form method="get" action="<?php echo e(route('eleito.deputadofederal.filtrar.lista')); ?>">
  <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
  <label for="formGroupExampleInput" class="font-weight-bold">Nome:</label><br>
  <input type="text" name="nome" class="form-control-sm" id="formGroupExampleInput" placeholder="Pesquisar pelo nome...">
  <select name="partido" class="form-control-sm">
  <option value="0">Partido</option>
  <?php $__currentLoopData = $listaPartido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listaPar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($listaPar->id); ?>"><?php echo e($listaPar->nome); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <select name="estado" class="form-control-sm">
  <option value="0">Estado</option>
  <?php $__currentLoopData = $listaEstado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($lista->nome); ?>"><?php echo e($lista->nome); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <select name="sexo" class="form-control-sm">
  <option value="0">Sexo</option>
  <option value="Masculino">Masculino</option>
  <option value="Feminino">Feminino</option>
</select><br>
<br><input type="submit" class="btn btn-success btn-lg btn-block" value="Realizar Pesquisa">
 </form> 
  </div><!-- card body-->
</div>