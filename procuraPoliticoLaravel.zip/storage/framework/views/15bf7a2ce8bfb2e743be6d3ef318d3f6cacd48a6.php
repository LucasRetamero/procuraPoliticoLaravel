<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Eleitos</div>
                    <div class="card-body">
                    <?php $__currentLoopData = $eleito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('/admin/eleitos')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="<?php echo e(route('admin.eleitos.form.cadastrar')); ?>" class="btn btn-success btn-sm" title="Add New User">
                            <i class="fa fa-plus" aria-hidden="true"></i> Adicionar novo
                        </a>
                        <a href="<?php echo e(route('admin.eleitos.form.atualizar',['id'=>$item->id])); ?>" title="Edit User"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button></a>   
                        <a class="btn btn-danger btn-sm" onclick="return confirm('Deletar Eleitor?')" href="<?php echo e(route('admin.eleitos.deletar', $item->id)); ?>"><i class="fa fa-trash"></i> Deletar</a>            
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th><th>partido_id</th><th>grupo_id</th><th>Imagem</th><th>Nome</th><th>Naturalidade</th><th>Nascimento</th><th>Sexo</th><th>Estado</th><th>Gabinete</th><th>telefone</th><th>Email</th><th>Site</th><th>Escritorio</th><th>Status</th><th>Biografia</th><th>Projetos</th><th>Processos</th><th>Partidos/Mandatos</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><a href="<?php echo e(url('/admin/users', $item->id)); ?>"><?php echo e($item->partido_id); ?></a></td>
                                        <td><?php echo e($item->grupo_id); ?></td>
                                        <td><a href="<?php echo e($item->imagem); ?>" target="_blank"><?php echo e($item->imagem); ?></a></td>
                                        <td><?php echo e($item->nome); ?></td>
                                        <td><?php echo e($item->naturalidade); ?></td>
                                        <td><?php echo e($item->nascimento); ?></td>
                                        <td><?php echo e($item->sexo); ?></td>
                                        <td><?php echo e($item->estado); ?></td> 
                                        <td><?php echo e($item->gabinete); ?></td>  
                                        <td><?php echo e($item->telefone); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->site); ?></td>
                                        <td><?php echo e($item->escritorio); ?></td>
                                        <td><?php echo e($item->status); ?></td>
                                        <td><?php echo $item->biografia; ?></td>
                                        <td><?php echo $item->projetos; ?></td> 
                                        <td><?php echo $item->processos; ?></td>
                                        <td><?php echo $item->partidos; ?></td>          
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>