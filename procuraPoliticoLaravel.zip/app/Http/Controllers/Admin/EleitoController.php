<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Eleito\Eleito;
use App\Model\Eleito\Partido;
use App\Model\Eleito\Grupo;
use App\Model\Eleito\Estado;

class EleitoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    private $objEleito,$objPartido,$objGrupo,$objEstado;

    public function __construct(Eleito $objEleito,Partido $objPartido,Grupo $objGrupo,Estado $objEstado){
    $this->objEleito  = $objEleito;
    $this->objPartido = $objPartido; 
    $this->objGrupo   = $objGrupo; 
    $this->objEstado  = $objEstado;  
    }

    public function Index()
    {
    $eleito = $this->objEleito->BuscarTodos();
    $dadoGrupo = $this->objGrupo->BuscarTodosGrupo();
    return view('admin.eleitos.index',compact('eleito','dadoGrupo'));
    }
    public function IndexFormCadastro()
    {
    return view('admin.eleitos.create',['dadoPartidos'=>$this->objPartido->BuscarPartidos(),
                                        'dadoGrupos'  =>$this->objGrupo->BuscarTodosGrupo(),
                                        'dadoEstados'  =>$this->objEstado->BuscarEstados()]);
    }
    public function IndexFormAtualiza($id)
    {
    $eleito = $this->objEleito::where('id',$id)
                               ->get();
    return view('admin.eleitos.edit',['dadoPartidos'=>$this->objPartido->BuscarPartidos(),
                                      'dadoGrupos'  =>$this->objGrupo->BuscarTodosGrupo(),
                                      'dadoEstados' =>$this->objEstado->BuscarEstados(),
                                      'eleito'      =>$eleito->all()]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if($request['partido_id'] == "0"){
        $request['partido_id'] = "";
        }
        if($request['grupo_id'] == "0"){
        $request['grupo_id'] = "";    
        }
        if($request['sexo'] == "0"){
        $request['sexo'] = "";    
        }
        if($request['estado'] == "0"){
        $request['estado'] = "";    
        }
        if($request['status'] == "0"){
        $request['status'] = "";    
        }

        $this->validate($request,[
         'partido_id'   => 'required',
         'grupo_id'     => 'required',
         'imagem'       => 'required',
         'nome'         => 'required',
         'naturalidade' => 'required',
         'nascimento'   => 'required',
         'sexo'         => 'required',
         'estado'       => 'required',
         'gabinete'     => 'required',
         'telefone'     => 'required',
         'email'        => 'required',
         'site'         => 'required',
         'escritorio'   => 'required',
         'escolaridade' => 'required',
         'status'       => 'required',
         'biografia'    => 'required',
         'projetos'     => 'required',
         'processos'    => 'required',
         'partidos'     => 'required'
        ]);
       $verifica = $this->objEleito::create($request->all());
       if($verifica)
       return redirect()->route('admin.eleitos.lista')->with('flash_message', 'Eleitor Adicionado!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
    $dadoGrupo = $this->objGrupo->BuscarTodosGrupo();
    $eleito =  $this->objEleito::where('grupo_id',$request['grupo_id'])
                                 ->get();
    if($eleito && $eleito->count() > 0){
    $verificaId = $request['grupo_id'];
    return view('admin.eleitos.index',compact('eleito','dadoGrupo','verificaId'));
    }else{
    $eleito = $this->objEleito->BuscarTodos();
    $dadoGrupo = $this->objGrupo->BuscarTodosGrupo();
    return view('admin.eleitos.index',compact('eleito','dadoGrupo'));
    }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        if($request['partido_id'] == "0"){
            $request['partido_id'] = "";
            }
            if($request['grupo_id'] == "0"){
            $request['grupo_id'] = "";    
            }
            if($request['sexo'] == "0"){
            $request['sexo'] = "";    
            }
            if($request['estado'] == "0"){
            $request['estado'] = "";    
            }
            if($request['status'] == "0"){
            $request['status'] = "";    
            }
    
            $this->validate($request,[
             'partido_id'   => 'required',
             'grupo_id'     => 'required',
             'imagem'       => 'required',
             'nome'         => 'required',
             'naturalidade' => 'required',
             'nascimento'   => 'required',
             'sexo'         => 'required',
             'estado'       => 'required',
             'gabinete'     => 'required',
             'telefone'     => 'required',
             'email'        => 'required',
             'site'         => 'required',
             'escritorio'   => 'required',
             'escolaridade' => 'required',
             'status'       => 'required',
             'biografia'    => 'required',
             'projetos'     => 'required',
             'processos'    => 'required',
             'partidos'     => 'required'
            ]);
           $dados = $request->except(['_token','id','btnAcao']); 
           $verifica = $this->objEleito::where('id',$request['id'])
                                         ->update($dados);
           if($verifica)
           return redirect()->route('admin.eleitos.lista')->with('flash_message', 'Eleitor Atualizado!');  
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showEleito($id)
    {
        $eleito = $this->objEleito::where('id',$id)
                                    ->get();
        return view('admin.eleitos.show',compact('eleito'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
     $verifica = $this->objEleito::where('id',$id)
                                  ->delete();
     if($verifica)
     return $this->Index();
    }
}
