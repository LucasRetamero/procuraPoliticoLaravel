<?php

namespace App\Http\Controllers\Eleito;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Eleito\Presidente;

class PresidenteController extends Controller
{
    private $listaDados;
    private $objPresidente;
    
    public function __construct(Presidente $obj){
    $this->objPresidente = $obj;    
    }

    public function Index(){
        $ativo = 0;
        $nomeMenu = "Lista de Presidentes";
        $listaDados = $this->objPresidente->BuscarTodosLista();
        return view('eleito.presidente.lista.index',compact('ativo','nomeMenu','listaDados'));    
    }

    public function ExibirConteudo($id){
      $title="Procura Politico - Presidente";
      $ativo=0;
      $nomeMenu = "Informações";
      $buscarInfo = $this->objPresidente->BuscarUm($id);
      //dd($buscarInfo);
      return view('eleito.presidente.conteudo.index',compact('title','ativo','nomeMenu','buscarInfo'));  
    }
}
