<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['prefix' => 'presidente','namespace' => 'Eleito'], function () {
Route::get('/','PresidenteController@Index')->name('eleito.presidente.lista.home');    
Route::get('conteudo/{id}','PresidenteController@ExibirConteudo')->name('eleito.presidente.conteudo');
});
Route::group(['prefix' => 'deputadofederal','namespace' => 'Eleito'], function () {
Route::get('/','DeputadoFederalController@Index')->name('eleito.deputadofederal.home');
Route::get('conteudo/{id}','DeputadoFederalController@ExibirConteudo')->name('eleito.deputadofederal.conteudo'); 
Route::get('/filtrarlista','DeputadoFederalController@ListaFiltrada')->name('eleito.deputadofederal.filtrar.lista');
});
Route::group(['prefix' => 'senador','namespace' => 'Eleito'], function () {
Route::get('/','SenadorController@Index')->name('eleito.senador.home');
Route::get('conteudo/{id}','SenadorController@ExibirConteudo')->name('eleito.senador.conteudo');
Route::get('/filtrarlista','SenadorController@ListaFiltrada')->name('eleito.senador.filtrar.lista');
});
Route::group(['prefix' => 'governador','namespace' => 'Eleito'], function () {
Route::get('/','GovernadorController@Index')->name('eleito.governador.home');
Route::get('conteudo/{id}','GovernadorController@ExibirConteudo')->name('eleito.governador.conteudo');        
Route::get('/filtrarlista','GovernadorController@ListaFiltrada')->name('eleito.governador.filtrar.lista');
});
Route::group(['prefix' => 'deputadoEstadual','namespace' => 'Eleito'], function () {
Route::get('/','DeputadoEstadualController@Index')->name('eleito.deputadoestadual.home');
Route::get('conteudo/{id}','DeputadoEstadualController@ExibirConteudo')->name('eleito.deputadoestadual.conteudo');
Route::get('/filtrarlista','DeputadoEstadualController@ListaFiltrada')->name('eleito.deputadoestadual.filtar.lista');
});
Route::group(['prefix' => 'vereador','namespace' => 'Eleito'], function () {
Route::get('/','VereadorController@Index')->name('eleito.vereador.home');
Route::get('conteudo/{id}','VereadorController@ExibirConteudo')->name('eleito.vereador.conteudo');          
Route::get('/filtrarlista','VereadorController@ListaFiltrada')->name('eleito.vereador.filtrar.lista');
});
Route::group(['namespace'=>'Home'], function () {
Route::post('/contato','ContatoController@EnviarContato')->name('home.contato.enviar');    
Route::get('/','HomeController@Index')->name('home.index');
});
Route::group(['middleware'=>'auth','prefix'=>'admin','namespace'=>'Admin'],function(){
Route::get('/', 'AdminController@index');
Route::get('/eleitos', 'EleitoController@Index')->name('admin.eleitos.lista');
Route::post('/eleitoslistafiltrada','EleitoController@show')->name('admin.eleitos.lista.filtrada');
Route::get('/eleitos/cadastrar','EleitoController@IndexFormCadastro')->name('admin.eleitos.form.cadastrar');
Route::post('/eleitos/cadastrareleitor','EleitoController@store')->name('admin.eleitos.cadastrar');
Route::get('/eleitos/atualizar/{id}','EleitoController@IndexFormAtualiza')->name('admin.eleitos.form.atualizar');
Route::post('/eleitos/atualizareleitor','EleitoController@edit')->name('admin.eleitos.atualizar');
Route::get('/eleitos/visualizar/{id}','EleitoController@showEleito')->name('admin.eleitos.perfil');
Route::get('/eleitos/deletar/{id}','EleitoController@Destroy')->name('admin.eleitos.deletar');
Route::get('/grupos','GrupoController@Index')->name('admin.grupos.lista');
Route::post('/gruposlistafiltrada','GrupoController@FiltrarLetra')->name('admin.grupos.lista.filtrada');
Route::get('/grupos/cadastrar','GrupoController@IndexFormCadastrar')->name('admin.grupos.form.cadastrar');
Route::post('/grupos/cadastrargrupo','GrupoController@store')->name('admin.grupos.cadastrar');
Route::get('/grupos/atualizar/{id}','GrupoController@IndexFormAtualizar')->name('admin.grupo.form.atualizar');
Route::post('/grupos/atualizargrupo','GrupoController@edit')->name('admin.grupo.editar');
Route::get('/grupos/deletar/{id}','GrupoController@destroy')->name('admin.grupos.deletar');
Route::get('/partidos','PartidoController@Index')->name('admin.partidos.lista');
Route::post('/partidos/filtrarlista','PartidoController@FiltrarLista')->name('admin.partidos.lista.filtrar');
Route::get('/partidos/cadastrar','PartidoController@IndexFormCadastrar')->name('admin.partidos.form.cadastrar');
Route::post('/partidos/cadastrarpartido','PartidoController@store')->name('admin.partidos.cadastrar');
Route::get('/partidos/editar/{id}','PartidoController@IndexFormAtualizar')->name('admin.partidos.form.editar');
Route::post('/partidos/editar','PartidoController@edit')->name('admin.partidos.editar');
Route::get('/partidos/deletar/{id}','PartidoController@destroyer')->name('admin.partidos.deletar');
Route::get('/contatos','ContatoController@Index')->name('admin.contato.lista');
Route::get('/contatos/show/{id}','ContatoController@ShowContatos')->name('admin.contato.show');
Route::get('/contatos/deletar/{id}','ContatoController@Destroyer')->name('admin.contato.deletar');
Route::post('/contatos/filtrarlista','ContatoController@IndexFiltrada')->name('admin.contato.lista.filtrar');
Route::resource('/users', 'UsersController');
});
//Route::resource('admin/settings', 'Admin\SettingsController');
Auth::routes();
Route::get('/home', 'Home\HomeController@Index')->name('home');


