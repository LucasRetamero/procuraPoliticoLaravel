<?php

use Illuminate\Database\Seeder;
use App\Model\Eleito\Eleito;

class EleitoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      Eleito::create([
        'partido_id'   => '1',
        'grupo_id'     => '1',
        'imagem'       => 'http://www.senado.gov.br/senadores/img/fotos-oficiais/senador4558.jpg',
        'nome'         => 'Gladson de Lima Cameli',
        'naturalidade' => 'Cruzeiro do Sul (AC)',
        'nascimento'   => '1978-03-26',
        'sexo'         => 'Masculino',
        'estado'       =>  'SP',
        'gabinete'     => 'Senado Federal Anexo 2 Ala Teotônio Vilela Gabinete 14',
        'telefone'     => '(61) 3303-1357 / 1367',
        'email'        => 'gladson.cameli@senador.leg.br',
        'site'         => 'http://www.senado.leg.br/senadores/senador/GladsonCameli/Default.asp',
        'escritorio'   => 'AVENIDA TRAVESSA BOA VISTA, 111. ISAURA PARENTE, RIO BRANCO, AC. CEP:69918306',
        'status'       => 'Presidente',
        'escolaridade' => 'Ensino Superior Completo',
        'biografia'    => '<p class="text-justify">É bacharel em Engenharia civil desde 2001, formado pelo Instituto Luterano de Ensino Superior de Manaus (ULBRA), no Amazonas. Membro do Conselho Regional de Engenharia, Arquitetura e Agronomia (CREA/AC), exerce atividades profissionais como sócio da empresa pertencente à família.[3] Pelo lado paterno, é sobrinho do ex-governador do estado do Acre, Orleir Cameli.[4]

        Membro do Conselho Municipal da Juventude, estreou na vida pública aos 28 anos quando eleito pela primeira vez para o mandato de deputado federal com 18.886 votos. Eleito pela segunda vez deputado nas eleições em 2010, com mais de 30 mil votos. Em outubro de 2009, foi condecorado com o Título de Cidadão Rio Branquense pela Câmara Municipal de Rio Branco/AC.
        
        Foi filiado ao PFL durante (2000-2003) e ao PPS durante (2003-2005). É filiado ao PP desde 2005 permanecendo até os dias atuais. Nas eleições estaduais de 2014 elegeu-se senador pelo Acre.
        
        Na Câmara dos Deputados, foi considerado por dois anos consecutivos, o campeão em liberação de recursos e emendas. Ele também apresentou projetos de lei importantes como a obrigatoriedade da instalação de câmeras de segurança nas escolas públicas. Foi relator do projeto da Zona de Processamento de Exportação. Foi presidente da Comissão da Amazônia, integrou a Comissão de Constituição e Justiça, uma das mais importantes do Congresso.</p><br>
        <div class="alert alert-success" role="alert">
         Historico Academico
        </div>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Curso</th>
              <th scope="col">Grau</th>
              <th scope="col">Estabelecimento</th>
              <th scope="col">Local</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Engenharia Civil</th>
              <td>Superior</td>
              <td>Instituto Luterano de Ensino Superior de Manaus - ULBRA</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Médio</th>
              <td>Ginasio</td>
              <td>Instituto Batista do Amazonas (IBA)</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Fundamental</th>
              <td>Primeiro Grau</td>
              <td>Escola São José</td>
              <td>Cruzeiro do Sul</td>
            </tr>
          </tbody>
        </table><br>
        <div class="alert alert-success" role="alert">
         Profissões
        </div>
        <ul>
        <li>Engenheiro</li>
        <li>Politico(Função Atual)</li>
        <li>Empresário</li>
        </ul>
        ',
        'projetos'     => '<table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/122098" target="_blanK">
      SF PEC 88/2015</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Modifica os arts. 54 e 56 da Constituição Federal, para vedar aos Deputados e Senadores a investidura em outro cargo ou mandato público.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli, Senador Acir Gurgacz, Senadora Ana Amélia, Senadora Ângela Portela, Senador Antonio Anastasia, Senador Benedito de Lira, Senador Blairo Maggi, Senador Ciro Nogueira, Senador Cristovam Buarque, Senador Davi Alcolumbre, Senador Donizeti Nogueira, Senador Elmano Férrer, Senador Garibaldi Alves Filho, Senador Hélio José, Senador Ivo Cassol, Senador José Agripino, Senador Lasier Martins, Senadora Maria do Carmo Alves, Senador Omar Aziz, Senador Paulo Paim, Senador Randolfe Rodrigues, Senador Reguffe, Senador Romário, Senador Sérgio Petecão, Senador Telmário Mota, Senador Vicentinho Alves, Senador Wilder Morais, Senador Zeze Perrella</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>02/07/2015</td>
          </tr>
        </tbody>
      </table>
      <hr>
      <table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/133893" target="_blanK">SF PLS 330/2018</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Altera a Lei 8.069, de 13 de julho de 1990 (Estatuto da Criança e do Adolescente), para permitir a utilização de nome afetivo para crianças em processo de adoção.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>10/07/2018</td>
          </tr>
        </tbody>
      </table>',
        'processos'    => 'Não foi possivel encontrar nenhum processo feito contra o 
        Gladson de Lima Cameli.',
        'partidos'     => ' <div class="alert alert-success" role="alert">
        Partidos
       </div>
       <table class="table">
        <thead>
          <tr>
            <th scope="col">Partido</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">PSOL</th>
          </tr>
        </tbody>
      </table>
      <div class="alert alert-success" role="alert">
      Mandatos
     </div>
     <table class="table">
     <thead>
       <tr>
         <th scope="col">Mandato</th>
         <th scope="col">Inicio</th>
         <th scope="col">Fim</th>
       </tr>
     </thead>
     <tbody>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2007</td>
         <td>2011</td>
       </tr>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2011</td>
         <td>2015</td>
       </tr>
       <tr>
         <th scope="row">Senador - AC</th>
         <td>2015</td>
         <td>--</td>
       </tr>
     </tbody>
   </table>
      '
      ]);

      Eleito::create([
        'partido_id'   => '1',
        'grupo_id'     => '2',
        'imagem'       => 'http://www.senado.gov.br/senadores/img/fotos-oficiais/senador4558.jpg',
        'nome'         => 'Gladson de Lima Cameli',
        'naturalidade' => 'Cruzeiro do Sul (AC)',
        'nascimento'   => '1978-03-26',
        'sexo'         => 'Masculino',
        'estado'       =>  'SP',
        'gabinete'     => 'Senado Federal Anexo 2 Ala Teotônio Vilela Gabinete 14',
        'telefone'     => '(61) 3303-1357 / 1367',
        'email'        => 'gladson.cameli@senador.leg.br',
        'site'         => 'http://www.senado.leg.br/senadores/senador/GladsonCameli/Default.asp',
        'escritorio'   => 'AVENIDA TRAVESSA BOA VISTA, 111. ISAURA PARENTE, RIO BRANCO, AC. CEP:69918306',
        'status'       => 'Deputado Federal',
        'escolaridade' => 'Ensino Superior Completo',
        'biografia'    => '<p class="text-justify">É bacharel em Engenharia civil desde 2001, formado pelo Instituto Luterano de Ensino Superior de Manaus (ULBRA), no Amazonas. Membro do Conselho Regional de Engenharia, Arquitetura e Agronomia (CREA/AC), exerce atividades profissionais como sócio da empresa pertencente à família.[3] Pelo lado paterno, é sobrinho do ex-governador do estado do Acre, Orleir Cameli.[4]

        Membro do Conselho Municipal da Juventude, estreou na vida pública aos 28 anos quando eleito pela primeira vez para o mandato de deputado federal com 18.886 votos. Eleito pela segunda vez deputado nas eleições em 2010, com mais de 30 mil votos. Em outubro de 2009, foi condecorado com o Título de Cidadão Rio Branquense pela Câmara Municipal de Rio Branco/AC.
        
        Foi filiado ao PFL durante (2000-2003) e ao PPS durante (2003-2005). É filiado ao PP desde 2005 permanecendo até os dias atuais. Nas eleições estaduais de 2014 elegeu-se senador pelo Acre.
        
        Na Câmara dos Deputados, foi considerado por dois anos consecutivos, o campeão em liberação de recursos e emendas. Ele também apresentou projetos de lei importantes como a obrigatoriedade da instalação de câmeras de segurança nas escolas públicas. Foi relator do projeto da Zona de Processamento de Exportação. Foi presidente da Comissão da Amazônia, integrou a Comissão de Constituição e Justiça, uma das mais importantes do Congresso.</p><br>
        <div class="alert alert-success" role="alert">
         Historico Academico
        </div>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Curso</th>
              <th scope="col">Grau</th>
              <th scope="col">Estabelecimento</th>
              <th scope="col">Local</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Engenharia Civil</th>
              <td>Superior</td>
              <td>Instituto Luterano de Ensino Superior de Manaus - ULBRA</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Médio</th>
              <td>Ginasio</td>
              <td>Instituto Batista do Amazonas (IBA)</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Fundamental</th>
              <td>Primeiro Grau</td>
              <td>Escola São José</td>
              <td>Cruzeiro do Sul</td>
            </tr>
          </tbody>
        </table><br>
        <div class="alert alert-success" role="alert">
         Profissões
        </div>
        <ul>
        <li>Engenheiro</li>
        <li>Politico(Função Atual)</li>
        <li>Empresário</li>
        </ul>
        ',
        'projetos'     => '<table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/122098" target="_blanK">
      SF PEC 88/2015</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Modifica os arts. 54 e 56 da Constituição Federal, para vedar aos Deputados e Senadores a investidura em outro cargo ou mandato público.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli, Senador Acir Gurgacz, Senadora Ana Amélia, Senadora Ângela Portela, Senador Antonio Anastasia, Senador Benedito de Lira, Senador Blairo Maggi, Senador Ciro Nogueira, Senador Cristovam Buarque, Senador Davi Alcolumbre, Senador Donizeti Nogueira, Senador Elmano Férrer, Senador Garibaldi Alves Filho, Senador Hélio José, Senador Ivo Cassol, Senador José Agripino, Senador Lasier Martins, Senadora Maria do Carmo Alves, Senador Omar Aziz, Senador Paulo Paim, Senador Randolfe Rodrigues, Senador Reguffe, Senador Romário, Senador Sérgio Petecão, Senador Telmário Mota, Senador Vicentinho Alves, Senador Wilder Morais, Senador Zeze Perrella</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>02/07/2015</td>
          </tr>
        </tbody>
      </table>
      <hr>
      <table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/133893" target="_blanK">SF PLS 330/2018</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Altera a Lei 8.069, de 13 de julho de 1990 (Estatuto da Criança e do Adolescente), para permitir a utilização de nome afetivo para crianças em processo de adoção.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>10/07/2018</td>
          </tr>
        </tbody>
      </table>',
        'processos'    => 'Não foi possivel encontrar nenhum processo feito contra o 
        Gladson de Lima Cameli.',
        'partidos'     => ' <div class="alert alert-success" role="alert">
        Partidos
       </div>
       <table class="table">
        <thead>
          <tr>
            <th scope="col">Partido</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">PSOL</th>
          </tr>
        </tbody>
      </table>
      <div class="alert alert-success" role="alert">
      Mandatos
     </div>
     <table class="table">
     <thead>
       <tr>
         <th scope="col">Mandato</th>
         <th scope="col">Inicio</th>
         <th scope="col">Fim</th>
       </tr>
     </thead>
     <tbody>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2007</td>
         <td>2011</td>
       </tr>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2011</td>
         <td>2015</td>
       </tr>
       <tr>
         <th scope="row">Senador - AC</th>
         <td>2015</td>
         <td>--</td>
       </tr>
     </tbody>
   </table>
      '
      ]);

      Eleito::create([
        'partido_id'   => '1',
        'grupo_id'     => '3',
        'imagem'       => 'http://www.senado.gov.br/senadores/img/fotos-oficiais/senador4558.jpg',
        'nome'         => 'Gladson de Lima Cameli',
        'naturalidade' => 'Cruzeiro do Sul (AC)',
        'nascimento'   => '1978-03-26',
        'sexo'         => 'Masculino',
        'estado'       =>  'SP',
        'gabinete'     => 'Senado Federal Anexo 2 Ala Teotônio Vilela Gabinete 14',
        'telefone'     => '(61) 3303-1357 / 1367',
        'email'        => 'gladson.cameli@senador.leg.br',
        'site'         => 'http://www.senado.leg.br/senadores/senador/GladsonCameli/Default.asp',
        'escritorio'   => 'AVENIDA TRAVESSA BOA VISTA, 111. ISAURA PARENTE, RIO BRANCO, AC. CEP:69918306',
        'status'       => 'Senador',
        'escolaridade' => 'Ensino Superior Completo',
        'biografia'    => '<p class="text-justify">É bacharel em Engenharia civil desde 2001, formado pelo Instituto Luterano de Ensino Superior de Manaus (ULBRA), no Amazonas. Membro do Conselho Regional de Engenharia, Arquitetura e Agronomia (CREA/AC), exerce atividades profissionais como sócio da empresa pertencente à família.[3] Pelo lado paterno, é sobrinho do ex-governador do estado do Acre, Orleir Cameli.[4]

        Membro do Conselho Municipal da Juventude, estreou na vida pública aos 28 anos quando eleito pela primeira vez para o mandato de deputado federal com 18.886 votos. Eleito pela segunda vez deputado nas eleições em 2010, com mais de 30 mil votos. Em outubro de 2009, foi condecorado com o Título de Cidadão Rio Branquense pela Câmara Municipal de Rio Branco/AC.
        
        Foi filiado ao PFL durante (2000-2003) e ao PPS durante (2003-2005). É filiado ao PP desde 2005 permanecendo até os dias atuais. Nas eleições estaduais de 2014 elegeu-se senador pelo Acre.
        
        Na Câmara dos Deputados, foi considerado por dois anos consecutivos, o campeão em liberação de recursos e emendas. Ele também apresentou projetos de lei importantes como a obrigatoriedade da instalação de câmeras de segurança nas escolas públicas. Foi relator do projeto da Zona de Processamento de Exportação. Foi presidente da Comissão da Amazônia, integrou a Comissão de Constituição e Justiça, uma das mais importantes do Congresso.</p><br>
        <div class="alert alert-success" role="alert">
         Historico Academico
        </div>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Curso</th>
              <th scope="col">Grau</th>
              <th scope="col">Estabelecimento</th>
              <th scope="col">Local</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Engenharia Civil</th>
              <td>Superior</td>
              <td>Instituto Luterano de Ensino Superior de Manaus - ULBRA</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Médio</th>
              <td>Ginasio</td>
              <td>Instituto Batista do Amazonas (IBA)</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Fundamental</th>
              <td>Primeiro Grau</td>
              <td>Escola São José</td>
              <td>Cruzeiro do Sul</td>
            </tr>
          </tbody>
        </table><br>
        <div class="alert alert-success" role="alert">
         Profissões
        </div>
        <ul>
        <li>Engenheiro</li>
        <li>Politico(Função Atual)</li>
        <li>Empresário</li>
        </ul>
        ',
        'projetos'     => '<table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/122098" target="_blanK">
      SF PEC 88/2015</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Modifica os arts. 54 e 56 da Constituição Federal, para vedar aos Deputados e Senadores a investidura em outro cargo ou mandato público.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli, Senador Acir Gurgacz, Senadora Ana Amélia, Senadora Ângela Portela, Senador Antonio Anastasia, Senador Benedito de Lira, Senador Blairo Maggi, Senador Ciro Nogueira, Senador Cristovam Buarque, Senador Davi Alcolumbre, Senador Donizeti Nogueira, Senador Elmano Férrer, Senador Garibaldi Alves Filho, Senador Hélio José, Senador Ivo Cassol, Senador José Agripino, Senador Lasier Martins, Senadora Maria do Carmo Alves, Senador Omar Aziz, Senador Paulo Paim, Senador Randolfe Rodrigues, Senador Reguffe, Senador Romário, Senador Sérgio Petecão, Senador Telmário Mota, Senador Vicentinho Alves, Senador Wilder Morais, Senador Zeze Perrella</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>02/07/2015</td>
          </tr>
        </tbody>
      </table>
      <hr>
      <table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/133893" target="_blanK">SF PLS 330/2018</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Altera a Lei 8.069, de 13 de julho de 1990 (Estatuto da Criança e do Adolescente), para permitir a utilização de nome afetivo para crianças em processo de adoção.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>10/07/2018</td>
          </tr>
        </tbody>
      </table>',
        'processos'    => 'Não foi possivel encontrar nenhum processo feito contra o 
        Gladson de Lima Cameli.',
        'partidos'     => ' <div class="alert alert-success" role="alert">
        Partidos
       </div>
       <table class="table">
        <thead>
          <tr>
            <th scope="col">Partido</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">PSOL</th>
          </tr>
        </tbody>
      </table>
      <div class="alert alert-success" role="alert">
      Mandatos
     </div>
     <table class="table">
     <thead>
       <tr>
         <th scope="col">Mandato</th>
         <th scope="col">Inicio</th>
         <th scope="col">Fim</th>
       </tr>
     </thead>
     <tbody>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2007</td>
         <td>2011</td>
       </tr>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2011</td>
         <td>2015</td>
       </tr>
       <tr>
         <th scope="row">Senador - AC</th>
         <td>2015</td>
         <td>--</td>
       </tr>
     </tbody>
   </table>
      '
      ]);

    
      Eleito::create([
        'partido_id'   => '1',
        'grupo_id'     => '4',
        'imagem'       => 'http://www.senado.gov.br/senadores/img/fotos-oficiais/senador4558.jpg',
        'nome'         => 'Gladson de Lima Cameli',
        'naturalidade' => 'Cruzeiro do Sul (AC)',
        'nascimento'   => '1978-03-26',
        'sexo'         => 'Masculino',
        'estado'       =>  'SP',
        'gabinete'     => 'Senado Federal Anexo 2 Ala Teotônio Vilela Gabinete 14',
        'telefone'     => '(61) 3303-1357 / 1367',
        'email'        => 'gladson.cameli@senador.leg.br',
        'site'         => 'http://www.senado.leg.br/senadores/senador/GladsonCameli/Default.asp',
        'escritorio'   => 'AVENIDA TRAVESSA BOA VISTA, 111. ISAURA PARENTE, RIO BRANCO, AC. CEP:69918306',
        'status'       => 'Governador',
        'escolaridade' => 'Ensino Superior Completo',
        'biografia'    => '<p class="text-justify">É bacharel em Engenharia civil desde 2001, formado pelo Instituto Luterano de Ensino Superior de Manaus (ULBRA), no Amazonas. Membro do Conselho Regional de Engenharia, Arquitetura e Agronomia (CREA/AC), exerce atividades profissionais como sócio da empresa pertencente à família.[3] Pelo lado paterno, é sobrinho do ex-governador do estado do Acre, Orleir Cameli.[4]

        Membro do Conselho Municipal da Juventude, estreou na vida pública aos 28 anos quando eleito pela primeira vez para o mandato de deputado federal com 18.886 votos. Eleito pela segunda vez deputado nas eleições em 2010, com mais de 30 mil votos. Em outubro de 2009, foi condecorado com o Título de Cidadão Rio Branquense pela Câmara Municipal de Rio Branco/AC.
        
        Foi filiado ao PFL durante (2000-2003) e ao PPS durante (2003-2005). É filiado ao PP desde 2005 permanecendo até os dias atuais. Nas eleições estaduais de 2014 elegeu-se senador pelo Acre.
        
        Na Câmara dos Deputados, foi considerado por dois anos consecutivos, o campeão em liberação de recursos e emendas. Ele também apresentou projetos de lei importantes como a obrigatoriedade da instalação de câmeras de segurança nas escolas públicas. Foi relator do projeto da Zona de Processamento de Exportação. Foi presidente da Comissão da Amazônia, integrou a Comissão de Constituição e Justiça, uma das mais importantes do Congresso.</p><br>
        <div class="alert alert-success" role="alert">
         Historico Academico
        </div>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Curso</th>
              <th scope="col">Grau</th>
              <th scope="col">Estabelecimento</th>
              <th scope="col">Local</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Engenharia Civil</th>
              <td>Superior</td>
              <td>Instituto Luterano de Ensino Superior de Manaus - ULBRA</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Médio</th>
              <td>Ginasio</td>
              <td>Instituto Batista do Amazonas (IBA)</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Fundamental</th>
              <td>Primeiro Grau</td>
              <td>Escola São José</td>
              <td>Cruzeiro do Sul</td>
            </tr>
          </tbody>
        </table><br>
        <div class="alert alert-success" role="alert">
         Profissões
        </div>
        <ul>
        <li>Engenheiro</li>
        <li>Politico(Função Atual)</li>
        <li>Empresário</li>
        </ul>
        ',
        'projetos'     => '<table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/122098" target="_blanK">
      SF PEC 88/2015</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Modifica os arts. 54 e 56 da Constituição Federal, para vedar aos Deputados e Senadores a investidura em outro cargo ou mandato público.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli, Senador Acir Gurgacz, Senadora Ana Amélia, Senadora Ângela Portela, Senador Antonio Anastasia, Senador Benedito de Lira, Senador Blairo Maggi, Senador Ciro Nogueira, Senador Cristovam Buarque, Senador Davi Alcolumbre, Senador Donizeti Nogueira, Senador Elmano Férrer, Senador Garibaldi Alves Filho, Senador Hélio José, Senador Ivo Cassol, Senador José Agripino, Senador Lasier Martins, Senadora Maria do Carmo Alves, Senador Omar Aziz, Senador Paulo Paim, Senador Randolfe Rodrigues, Senador Reguffe, Senador Romário, Senador Sérgio Petecão, Senador Telmário Mota, Senador Vicentinho Alves, Senador Wilder Morais, Senador Zeze Perrella</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>02/07/2015</td>
          </tr>
        </tbody>
      </table>
      <hr>
      <table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/133893" target="_blanK">SF PLS 330/2018</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Altera a Lei 8.069, de 13 de julho de 1990 (Estatuto da Criança e do Adolescente), para permitir a utilização de nome afetivo para crianças em processo de adoção.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>10/07/2018</td>
          </tr>
        </tbody>
      </table>',
        'processos'    => 'Não foi possivel encontrar nenhum processo feito contra o 
        Gladson de Lima Cameli.',
        'partidos'     => ' <div class="alert alert-success" role="alert">
        Partidos
       </div>
       <table class="table">
        <thead>
          <tr>
            <th scope="col">Partido</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">PSOL</th>
          </tr>
        </tbody>
      </table>
      <div class="alert alert-success" role="alert">
      Mandatos
     </div>
     <table class="table">
     <thead>
       <tr>
         <th scope="col">Mandato</th>
         <th scope="col">Inicio</th>
         <th scope="col">Fim</th>
       </tr>
     </thead>
     <tbody>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2007</td>
         <td>2011</td>
       </tr>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2011</td>
         <td>2015</td>
       </tr>
       <tr>
         <th scope="row">Senador - AC</th>
         <td>2015</td>
         <td>--</td>
       </tr>
     </tbody>
   </table>
      '
      ]);
    
      
      Eleito::create([
        'partido_id'   => '1',
        'grupo_id'     => '5',
        'imagem'       => 'http://www.senado.gov.br/senadores/img/fotos-oficiais/senador4558.jpg',
        'nome'         => 'Gladson de Lima Cameli',
        'naturalidade' => 'Cruzeiro do Sul (AC)',
        'nascimento'   => '1978-03-26',
        'sexo'         => 'Masculino',
        'estado'       =>  'SP',
        'gabinete'     => 'Senado Federal Anexo 2 Ala Teotônio Vilela Gabinete 14',
        'telefone'     => '(61) 3303-1357 / 1367',
        'email'        => 'gladson.cameli@senador.leg.br',
        'site'         => 'http://www.senado.leg.br/senadores/senador/GladsonCameli/Default.asp',
        'escritorio'   => 'AVENIDA TRAVESSA BOA VISTA, 111. ISAURA PARENTE, RIO BRANCO, AC. CEP:69918306',
        'status'       => 'Deputado Estadual',
        'escolaridade' => 'Ensino Superior Completo',
        'biografia'    => '<p class="text-justify">É bacharel em Engenharia civil desde 2001, formado pelo Instituto Luterano de Ensino Superior de Manaus (ULBRA), no Amazonas. Membro do Conselho Regional de Engenharia, Arquitetura e Agronomia (CREA/AC), exerce atividades profissionais como sócio da empresa pertencente à família.[3] Pelo lado paterno, é sobrinho do ex-governador do estado do Acre, Orleir Cameli.[4]

        Membro do Conselho Municipal da Juventude, estreou na vida pública aos 28 anos quando eleito pela primeira vez para o mandato de deputado federal com 18.886 votos. Eleito pela segunda vez deputado nas eleições em 2010, com mais de 30 mil votos. Em outubro de 2009, foi condecorado com o Título de Cidadão Rio Branquense pela Câmara Municipal de Rio Branco/AC.
        
        Foi filiado ao PFL durante (2000-2003) e ao PPS durante (2003-2005). É filiado ao PP desde 2005 permanecendo até os dias atuais. Nas eleições estaduais de 2014 elegeu-se senador pelo Acre.
        
        Na Câmara dos Deputados, foi considerado por dois anos consecutivos, o campeão em liberação de recursos e emendas. Ele também apresentou projetos de lei importantes como a obrigatoriedade da instalação de câmeras de segurança nas escolas públicas. Foi relator do projeto da Zona de Processamento de Exportação. Foi presidente da Comissão da Amazônia, integrou a Comissão de Constituição e Justiça, uma das mais importantes do Congresso.</p><br>
        <div class="alert alert-success" role="alert">
         Historico Academico
        </div>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Curso</th>
              <th scope="col">Grau</th>
              <th scope="col">Estabelecimento</th>
              <th scope="col">Local</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Engenharia Civil</th>
              <td>Superior</td>
              <td>Instituto Luterano de Ensino Superior de Manaus - ULBRA</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Médio</th>
              <td>Ginasio</td>
              <td>Instituto Batista do Amazonas (IBA)</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Fundamental</th>
              <td>Primeiro Grau</td>
              <td>Escola São José</td>
              <td>Cruzeiro do Sul</td>
            </tr>
          </tbody>
        </table><br>
        <div class="alert alert-success" role="alert">
         Profissões
        </div>
        <ul>
        <li>Engenheiro</li>
        <li>Politico(Função Atual)</li>
        <li>Empresário</li>
        </ul>
        ',
        'projetos'     => '<table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/122098" target="_blanK">
      SF PEC 88/2015</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Modifica os arts. 54 e 56 da Constituição Federal, para vedar aos Deputados e Senadores a investidura em outro cargo ou mandato público.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli, Senador Acir Gurgacz, Senadora Ana Amélia, Senadora Ângela Portela, Senador Antonio Anastasia, Senador Benedito de Lira, Senador Blairo Maggi, Senador Ciro Nogueira, Senador Cristovam Buarque, Senador Davi Alcolumbre, Senador Donizeti Nogueira, Senador Elmano Férrer, Senador Garibaldi Alves Filho, Senador Hélio José, Senador Ivo Cassol, Senador José Agripino, Senador Lasier Martins, Senadora Maria do Carmo Alves, Senador Omar Aziz, Senador Paulo Paim, Senador Randolfe Rodrigues, Senador Reguffe, Senador Romário, Senador Sérgio Petecão, Senador Telmário Mota, Senador Vicentinho Alves, Senador Wilder Morais, Senador Zeze Perrella</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>02/07/2015</td>
          </tr>
        </tbody>
      </table>
      <hr>
      <table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/133893" target="_blanK">SF PLS 330/2018</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Altera a Lei 8.069, de 13 de julho de 1990 (Estatuto da Criança e do Adolescente), para permitir a utilização de nome afetivo para crianças em processo de adoção.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>10/07/2018</td>
          </tr>
        </tbody>
      </table>',
        'processos'    => 'Não foi possivel encontrar nenhum processo feito contra o 
        Gladson de Lima Cameli.',
        'partidos'     => ' <div class="alert alert-success" role="alert">
        Partidos
       </div>
       <table class="table">
        <thead>
          <tr>
            <th scope="col">Partido</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">PSOL</th>
          </tr>
        </tbody>
      </table>
      <div class="alert alert-success" role="alert">
      Mandatos
     </div>
     <table class="table">
     <thead>
       <tr>
         <th scope="col">Mandato</th>
         <th scope="col">Inicio</th>
         <th scope="col">Fim</th>
       </tr>
     </thead>
     <tbody>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2007</td>
         <td>2011</td>
       </tr>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2011</td>
         <td>2015</td>
       </tr>
       <tr>
         <th scope="row">Senador - AC</th>
         <td>2015</td>
         <td>--</td>
       </tr>
     </tbody>
   </table>
      '
      ]);
    
      
      Eleito::create([
        'partido_id'   => '1',
        'grupo_id'     => '6',
        'imagem'       => 'http://www.senado.gov.br/senadores/img/fotos-oficiais/senador4558.jpg',
        'nome'         => 'Gladson de Lima Cameli',
        'naturalidade' => 'Cruzeiro do Sul (AC)',
        'nascimento'   => '1978-03-26',
        'sexo'         => 'Masculino',
        'estado'       =>  'SP',
        'gabinete'     => 'Senado Federal Anexo 2 Ala Teotônio Vilela Gabinete 14',
        'telefone'     => '(61) 3303-1357 / 1367',
        'email'        => 'gladson.cameli@senador.leg.br',
        'site'         => 'http://www.senado.leg.br/senadores/senador/GladsonCameli/Default.asp',
        'escritorio'   => 'AVENIDA TRAVESSA BOA VISTA, 111. ISAURA PARENTE, RIO BRANCO, AC. CEP:69918306',
        'status'       => 'Vereador',
        'escolaridade' => 'Ensino Superior Completo',
        'biografia'    => '<p class="text-justify">É bacharel em Engenharia civil desde 2001, formado pelo Instituto Luterano de Ensino Superior de Manaus (ULBRA), no Amazonas. Membro do Conselho Regional de Engenharia, Arquitetura e Agronomia (CREA/AC), exerce atividades profissionais como sócio da empresa pertencente à família.[3] Pelo lado paterno, é sobrinho do ex-governador do estado do Acre, Orleir Cameli.[4]

        Membro do Conselho Municipal da Juventude, estreou na vida pública aos 28 anos quando eleito pela primeira vez para o mandato de deputado federal com 18.886 votos. Eleito pela segunda vez deputado nas eleições em 2010, com mais de 30 mil votos. Em outubro de 2009, foi condecorado com o Título de Cidadão Rio Branquense pela Câmara Municipal de Rio Branco/AC.
        
        Foi filiado ao PFL durante (2000-2003) e ao PPS durante (2003-2005). É filiado ao PP desde 2005 permanecendo até os dias atuais. Nas eleições estaduais de 2014 elegeu-se senador pelo Acre.
        
        Na Câmara dos Deputados, foi considerado por dois anos consecutivos, o campeão em liberação de recursos e emendas. Ele também apresentou projetos de lei importantes como a obrigatoriedade da instalação de câmeras de segurança nas escolas públicas. Foi relator do projeto da Zona de Processamento de Exportação. Foi presidente da Comissão da Amazônia, integrou a Comissão de Constituição e Justiça, uma das mais importantes do Congresso.</p><br>
        <div class="alert alert-success" role="alert">
         Historico Academico
        </div>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Curso</th>
              <th scope="col">Grau</th>
              <th scope="col">Estabelecimento</th>
              <th scope="col">Local</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Engenharia Civil</th>
              <td>Superior</td>
              <td>Instituto Luterano de Ensino Superior de Manaus - ULBRA</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Médio</th>
              <td>Ginasio</td>
              <td>Instituto Batista do Amazonas (IBA)</td>
              <td>Manaus</td>
            </tr>
            <tr>
              <th scope="row">Ensino Fundamental</th>
              <td>Primeiro Grau</td>
              <td>Escola São José</td>
              <td>Cruzeiro do Sul</td>
            </tr>
          </tbody>
        </table><br>
        <div class="alert alert-success" role="alert">
         Profissões
        </div>
        <ul>
        <li>Engenheiro</li>
        <li>Politico(Função Atual)</li>
        <li>Empresário</li>
        </ul>
        ',
        'projetos'     => '<table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/122098" target="_blanK">
      SF PEC 88/2015</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Modifica os arts. 54 e 56 da Constituição Federal, para vedar aos Deputados e Senadores a investidura em outro cargo ou mandato público.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli, Senador Acir Gurgacz, Senadora Ana Amélia, Senadora Ângela Portela, Senador Antonio Anastasia, Senador Benedito de Lira, Senador Blairo Maggi, Senador Ciro Nogueira, Senador Cristovam Buarque, Senador Davi Alcolumbre, Senador Donizeti Nogueira, Senador Elmano Férrer, Senador Garibaldi Alves Filho, Senador Hélio José, Senador Ivo Cassol, Senador José Agripino, Senador Lasier Martins, Senadora Maria do Carmo Alves, Senador Omar Aziz, Senador Paulo Paim, Senador Randolfe Rodrigues, Senador Reguffe, Senador Romário, Senador Sérgio Petecão, Senador Telmário Mota, Senador Vicentinho Alves, Senador Wilder Morais, Senador Zeze Perrella</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>02/07/2015</td>
          </tr>
        </tbody>
      </table>
      <hr>
      <table class="table table-bordered">
        <tbody>
          <tr>
            <th scope="row">Matéria:</th>
            <td><a href="https://www25.senado.leg.br/web/atividade/materias/-/materia/133893" target="_blanK">SF PLS 330/2018</a></td>
          </tr>
          <tr>
            <th scope="row">Ementa:</th>
            <td>Altera a Lei 8.069, de 13 de julho de 1990 (Estatuto da Criança e do Adolescente), para permitir a utilização de nome afetivo para crianças em processo de adoção.</td>
          </tr>
          <tr>
            <th scope="row">Autor:</th>
            <td>Senador Gladson Cameli</td>
          </tr>
          <tr>
            <th scope="row">Data:</th>
            <td>10/07/2018</td>
          </tr>
        </tbody>
      </table>',
        'processos'    => 'Não foi possivel encontrar nenhum processo feito contra o 
        Gladson de Lima Cameli.',
        'partidos'     => ' <div class="alert alert-success" role="alert">
        Partidos
       </div>
       <table class="table">
        <thead>
          <tr>
            <th scope="col">Partido</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">PSOL</th>
          </tr>
        </tbody>
      </table>
      <div class="alert alert-success" role="alert">
      Mandatos
     </div>
     <table class="table">
     <thead>
       <tr>
         <th scope="col">Mandato</th>
         <th scope="col">Inicio</th>
         <th scope="col">Fim</th>
       </tr>
     </thead>
     <tbody>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2007</td>
         <td>2011</td>
       </tr>
       <tr>
         <th scope="row">Deputado Federal - AC</th>
         <td>2011</td>
         <td>2015</td>
       </tr>
       <tr>
         <th scope="row">Senador - AC</th>
         <td>2015</td>
         <td>--</td>
       </tr>
     </tbody>
   </table>
      '
      ]);
    }
}
