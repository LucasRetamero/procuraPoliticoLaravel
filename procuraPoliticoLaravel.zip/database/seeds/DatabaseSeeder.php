<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(UserTableSeeder::class);
        $this->call(GrupoTableSeeder::class);
        $this->call(PartidoTableSeeder::class);
        $this->call(EstadoTableSeeder::class);
        $this->call(EleitoTableSeeder::class);
    }
}
