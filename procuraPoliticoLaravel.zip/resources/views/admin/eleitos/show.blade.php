@extends('layouts.backend')

@section('content')
    <div class="container">
        <div class="row">
            @include('admin.sidebar')

            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Eleitos</div>
                    <div class="card-body">
                    @foreach($eleito as $item)
                    <a href="{{ url('/admin/eleitos') }}" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="{{ route('admin.eleitos.form.cadastrar') }}" class="btn btn-success btn-sm" title="Add New User">
                            <i class="fa fa-plus" aria-hidden="true"></i> Adicionar novo
                        </a>
                        <a href="{{ route('admin.eleitos.form.atualizar',['id'=>$item->id])}}" title="Edit User"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button></a>   
                        <a class="btn btn-danger btn-sm" onclick="return confirm('Deletar Eleitor?')" href="{{route('admin.eleitos.deletar', $item->id)}}"><i class="fa fa-trash"></i> Deletar</a>            
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th><th>partido_id</th><th>grupo_id</th><th>Imagem</th><th>Nome</th><th>Naturalidade</th><th>Nascimento</th><th>Sexo</th><th>Estado</th><th>Gabinete</th><th>telefone</th><th>Email</th><th>Site</th><th>Escritorio</th><th>Status</th><th>Biografia</th><th>Projetos</th><th>Processos</th><th>Partidos/Mandatos</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>{{ $item->id }}</td>
                                        <td><a href="{{ url('/admin/users', $item->id) }}">{{ $item->partido_id }}</a></td>
                                        <td>{{ $item->grupo_id }}</td>
                                        <td><a href="{{$item->imagem}}" target="_blank">{{ $item->imagem }}</a></td>
                                        <td>{{ $item->nome }}</td>
                                        <td>{{ $item->naturalidade }}</td>
                                        <td>{{ $item->nascimento }}</td>
                                        <td>{{ $item->sexo }}</td>
                                        <td>{{ $item->estado }}</td> 
                                        <td>{{ $item->gabinete }}</td>  
                                        <td>{{ $item->telefone }}</td>
                                        <td>{{ $item->email }}</td>
                                        <td>{{ $item->site }}</td>
                                        <td>{{ $item->escritorio }}</td>
                                        <td>{{ $item->status }}</td>
                                        <td>{!! $item->biografia !!}</td>
                                        <td>{!! $item->projetos  !!}</td> 
                                        <td>{!! $item->processos !!}</td>
                                        <td>{!! $item->partidos  !!}</td>          
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
