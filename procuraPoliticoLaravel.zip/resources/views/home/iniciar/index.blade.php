<!doctype <!DOCTYPE html>
<html>
<head>
@include('home.head.index')
</head>
<body id="page-top">
@include('home.menu.index')
@include('home.title.index')
@include('home.section.index')
@include('home.footer.index')
</body>
</html>