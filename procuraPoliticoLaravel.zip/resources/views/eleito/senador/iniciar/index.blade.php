<!DOCTYPE html>
<html>
<head>
@include('home.head.index')
</head>
<body>
@include('home.menu.index')
@include('home.title.index')
@yield('content')
@include('home.footer.index')
</body>
</html>
